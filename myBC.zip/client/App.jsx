import * as React from 'react';

function App() {
  return (
    <div style={{ backgroundColor: 'blue' }}>React Test</div>
  );
}

export default App;