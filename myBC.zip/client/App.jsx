import * as React from 'react';

function App() {
  return (
    <div style={{ backgroundColor: 'pink' }}>React Test</div>
  );
}

export default App;