import * as React from 'react';
import * as ReactDOM from 'react-dom';

import App from './App.jsx';

// here we render the top level App component to the DOM
ReactDOM.render(<App />, document.getElementById('root'));